# attendance-system-1

本專案為學生出缺席登記系統第 1 版，可部署至 GitHub Pages 使用。